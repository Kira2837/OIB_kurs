//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
#include <tlhelp32.hpp>
bool blocking=false;
TStringList *b_list = new TStringList();
TStringList *res_list = new TStringList();

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

PACKAGE void __fastcall GetActiveAppList (TStringList *slist)
{
if (!slist) return;

slist->Clear();

TProcessEntry32 prj;
prj.dwSize = sizeof(PROCESSENTRY32);

HANDLE hss = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0);
if (((int)(hss)) == (-1)) return;

AnsiString fname;
try {
for (bool loop = Process32First(hss, &prj); loop; loop = Process32Next(hss, &prj))
{ fname = AnsiString(prj.szExeFile).Trim().UpperCase();
if (fname.IsEmpty()) continue;
slist->Add(fname);
}
} // try
catch (...) { slist->Clear(); }

CloseHandle(hss);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
//bool flag = false;
bool exist;

TStringList *slist = new TStringList();

try {
        GetActiveAppList(slist);
        Memo1->Lines = slist;
        if(blocking)
         {
          for(int i=0;i<slist->Count;i++)
           {
            exist = false;
            for(int j=0;j<b_list->Count;j++)
             {
              if(slist->Strings[i]==b_list->Strings[j]) exist = true;
             }
            if(!exist)
             {
             res_list->Add(slist->Strings[i]);
             AnsiString to_kill_process = "/f /im "+slist->Strings[i];
             HWND handle;
             ShellExecute(handle, NULL, "taskkill", to_kill_process.c_str(), NULL, SW_SHOWNORMAL);
             }
           }
          }
          else
          {
//          delete b_list;
//          delete res_list;
          }
        Memo2->Lines = res_list;
//        if(slist->operator [](i)==agent_name) flag=true;
    }
__finally
        {
         delete slist;
        }
//HWND handle;
//if(!flag) ShellExecute(handle, "open", "svahost.exe", NULL, NULL, SW_SHOWNORMAL);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
Timer1->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
Timer1->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
b_list->Clear();
GetActiveAppList(b_list);
b_list->Add("WMIPRVSE.EXE");
blocking = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
blocking = false;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Edit1Change(TObject *Sender)
{
if(Edit1->Text=="007")
 {
        Button4->Enabled = true;
        Button2->Enabled = true;
 }
else
 {
        Button4->Enabled = false;
        Button2->Enabled = false;
 }
}
//---------------------------------------------------------------------------

