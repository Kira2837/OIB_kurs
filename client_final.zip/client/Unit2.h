//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Grids.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TImage *Image1;
        TGroupBox *GroupBox2;
        TListBox *ListBox1;
        TPopupMenu *PopupMenu1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *N3;
        TPopupMenu *PopupMenu2;
        TMenuItem *N4;
        TMenuItem *N5;
        TGroupBox *GroupBox3;
        TGroupBox *GroupBox4;
        TGroupBox *GroupBox5;
        TStringGrid *StringGrid1;
        TStringGrid *StringGrid2;
        TStringGrid *StringGrid3;
        TPopupMenu *PopupMenu3;
        TPopupMenu *PopupMenu4;
        TMenuItem *N6;
        TTimer *Timer1;
        TMenuItem *N7;
        TMenuItem *N8;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall StringGrid1MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall StringGrid2MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall StringGrid3MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall N6Click(TObject *Sender);
        void __fastcall N1Click(TObject *Sender);
        void __fastcall N3Click(TObject *Sender);
        void __fastcall N2Click(TObject *Sender);
        void __fastcall N4Click(TObject *Sender);
        void __fastcall StringGrid2Click(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall StringGrid1Click(TObject *Sender);
        void __fastcall N8Click(TObject *Sender);
        void __fastcall N7Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm2(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif
