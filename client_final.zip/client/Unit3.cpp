//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button1Click(TObject *Sender)
{
  Timer1->Enabled = !Timer1->Enabled;
  if(Timer1->Enabled)
  {
    Button1->Caption = "����";
    Timer1->Interval = StrToFloat(Edit1->Text)*1000;
  }
  else  Button1->Caption = "�����";
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Timer1Timer(TObject *Sender)
{
  if(Timer1->Enabled)
  {
    Form1->NMUDP2->SendBuffer("04",strlen("04"),strlen("04"));
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormClose(TObject *Sender, TCloseAction &Action)
{
  Timer1->Enabled = false;
}
//---------------------------------------------------------------------------
