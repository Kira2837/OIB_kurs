//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <Tabnotbk.hpp>
#include "CGAUGES.h"
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <NMUDP.hpp>
#include <NMSTRM.hpp>
#include <Psock.hpp>
#include <TabNotBk.hpp>
//#include "RxGrdCpt.h"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TStatusBar *StatusBar1;
        TTabbedNotebook *TabbedNotebook1;
        TCGauge *CGauge1;
        TGroupBox *GroupBox1;
        TStringGrid *StringGrid1;
        TGroupBox *GroupBox2;
        TGroupBox *GroupBox3;
        TRadioButton *RadioButton1;
        TRadioButton *RadioButton2;
        TLabel *Label1;
        TCheckBox *CheckBox1;
        TLabel *Label2;
        TEdit *Edit1;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TEdit *Edit2;
        TEdit *Edit3;
        TEdit *Edit4;
        TEdit *Edit5;
        TEdit *Edit6;
        TEdit *Edit7;
        TEdit *Edit8;
        TEdit *Edit9;
        TLabel *Label6;
        TBitBtn *BitBtn1;
        TTabbedNotebook *TabbedNotebook2;
        TBitBtn *BitBtn2;
        TBitBtn *BitBtn3;
        TBitBtn *BitBtn4;
        TBitBtn *BitBtn5;
        TBitBtn *BitBtn6;
        TBitBtn *BitBtn7;
        TEdit *Edit10;
        TGroupBox *GroupBox4;
        TGroupBox *GroupBox5;
        TBitBtn *BitBtn8;
        TBitBtn *BitBtn9;
        TBitBtn *BitBtn10;
        TBitBtn *BitBtn11;
        TBitBtn *BitBtn12;
        TBitBtn *BitBtn13;
        TBitBtn *BitBtn14;
        TBitBtn *BitBtn15;
        TBitBtn *BitBtn16;
        TListBox *ListBox1;
        TTreeView *TreeView1;
        TGroupBox *GroupBox7;
        TStringGrid *StringGrid2;
        TTimer *Timer1;
        TTimer *Timer2;
        TMemo *Memo1;
        TNMUDP *NMUDP1;
        TTimer *Timer3;
        TNMStrm *NMStrm1;
        TNMStrmServ *NMStrmServ1;
        TNMUDP *NMUDP2;
        TNMStrmServ *NMStrmServ2;
        TBitBtn *BitBtn17;
        TBitBtn *BitBtn18;
        TBitBtn *BitBtn19;
        TBitBtn *BitBtn20;
        TRadioButton *RadioButton3;
        TRadioButton *RadioButton4;
        TRadioButton *RadioButton5;
        TRadioButton *RadioButton6;
        TPanel *Panel1;
        TBitBtn *BitBtn21;
        TBitBtn *BitBtn22;
        TBitBtn *BitBtn23;
        TBitBtn *BitBtn24;
        TBitBtn *BitBtn28;
        TBitBtn *BitBtn25;
        TBitBtn *BitBtn26;
        TBitBtn *BitBtn27;
        TBitBtn *BitBtn29;
        TBitBtn *BitBtn30;
        TMainMenu *MainMenu1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *N3;
        TMenuItem *N4;
        TButton *Button1;
        TEdit *Edit11;
        void __fastcall Sesion(char *Buf);
        void __fastcall SesionFiles(char *Buf);
        void __fastcall Hello(char* Buff);
        void __fastcall Shares(char* Buf);
        void __fastcall Traff(char *Buf);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall StringGrid2DblClick(TObject *Sender);
        void __fastcall RadioButton2Click(TObject *Sender);
        void __fastcall RadioButton1Click(TObject *Sender);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall Edit1Change(TObject *Sender);
        void __fastcall Timer2Timer(TObject *Sender);
        void __fastcall NMUDP1DataReceived(TComponent *Sender,
          int NumberBytes, AnsiString FromIP, int Port);
        void __fastcall Timer3Timer(TObject *Sender);
        void __fastcall NMStrmServ1MSG(TComponent *Sender,
          const AnsiString sFrom, TStream *strm);
        void __fastcall NMUDP2DataReceived(TComponent *Sender,
          int NumberBytes, AnsiString FromIP, int Port);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall BitBtn3Click(TObject *Sender);
        void __fastcall BitBtn4Click(TObject *Sender);
        void __fastcall BitBtn5Click(TObject *Sender);
        void __fastcall BitBtn6Click(TObject *Sender);
        void __fastcall BitBtn7Click(TObject *Sender);
        void __fastcall BitBtn8Click(TObject *Sender);
        void __fastcall BitBtn9Click(TObject *Sender);
        void __fastcall BitBtn10Click(TObject *Sender);
        void __fastcall BitBtn11Click(TObject *Sender);
        void __fastcall BitBtn12Click(TObject *Sender);
        void __fastcall BitBtn13Click(TObject *Sender);
        void __fastcall BitBtn14Click(TObject *Sender);
        void __fastcall BitBtn15Click(TObject *Sender);
        void __fastcall BitBtn16Click(TObject *Sender);
        void __fastcall NMStrmServ2MSG(TComponent *Sender,
          const AnsiString sFrom, TStream *strm);
        void __fastcall StringGrid1Click(TObject *Sender);
        void __fastcall BitBtn17Click(TObject *Sender);
        void __fastcall BitBtn18Click(TObject *Sender);
        void __fastcall BitBtn19Click(TObject *Sender);
        void __fastcall BitBtn20Click(TObject *Sender);
        void __fastcall BitBtn21Click(TObject *Sender);
        void __fastcall BitBtn22Click(TObject *Sender);
        void __fastcall BitBtn23Click(TObject *Sender);
        void __fastcall BitBtn24Click(TObject *Sender);
        void __fastcall BitBtn28Click(TObject *Sender);
        void __fastcall BitBtn25Click(TObject *Sender);
        void __fastcall BitBtn26Click(TObject *Sender);
        void __fastcall BitBtn27Click(TObject *Sender);
        void __fastcall BitBtn29Click(TObject *Sender);
        void __fastcall BitBtn30Click(TObject *Sender);
        void __fastcall N4Click(TObject *Sender);
        void __fastcall N3Click(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        
        

private:	// User declarations
public:		// User declarations
        bool ScD;
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
