//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormShow(TObject *Sender)
{
  StringGrid2->Cells[0][0] = "������������ ����������";
  StringGrid2->Cells[1][0] = "MAC �����";
  StringGrid2->Cells[2][0] = "������� ����";
  StringGrid2->Cells[3][0] = "���������� ����";

  StringGrid1->Cells[0][0] = "���������";
  StringGrid1->Cells[1][0] = "������������";
  StringGrid1->Cells[2][0] = "�������� ��������";
  StringGrid1->Cells[3][0] = "����� ��������";
  StringGrid1->Cells[4][0] = "����� �� ��������";

  StringGrid3->Cells[0][0] = "ID";
  StringGrid3->Cells[1][0] = "���� � �����";
  StringGrid3->Cells[2][0] = "��� ������������";
  Form1->NMUDP2->SendBuffer("01",strlen("01"),strlen("01"));
}
//---------------------------------------------------------------------------

void __fastcall TForm2::StringGrid1MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  int i=0,n0,n1,n2,n3,n4;
  StringGrid1->ShowHint = false;

  n0 = StringGrid1->ColWidths[0];
  n1 = StringGrid1->ColWidths[1];
  n2 = StringGrid1->ColWidths[2];
  n3 = StringGrid1->ColWidths[3];
  n4 = StringGrid1->ColWidths[4];

  if(X > 0 && X < n0)                          i=0;
  if(X > n0 && X < n0+n1)                      i=1;
  if(X > n0+n1 && X < n0+n1+n2)                i=2;
  if(X > n0+n1+n2 && X < n0+n1+n2+n3)          i=3;
  if(X > n0+n1+n2+n3 && X < n0+n1+n2+n2+n3+n4) i=4;

  if(Y<15) StringGrid1->Hint = StringGrid1->Cells[i][0];
  else StringGrid1->Hint = StringGrid1->Cells[i][StringGrid1->Row];
  StringGrid1->ShowHint = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::StringGrid2MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  int i=0,n0,n1,n2,n3;
  StringGrid2->ShowHint = false;

  n0 = StringGrid2->ColWidths[0];
  n1 = StringGrid2->ColWidths[1];
  n2 = StringGrid2->ColWidths[2];
  n3 = StringGrid2->ColWidths[3];

  if(X > 0 && X < n0)                          i=0;
  if(X > n0 && X < n0+n1)                      i=1;
  if(X > n0+n1 && X < n0+n1+n2)                i=2;
  if(X > n0+n1+n2 && X < n0+n1+n2+n3)          i=3;

  if(Y<15) StringGrid2->Hint = StringGrid2->Cells[i][0];
  else StringGrid2->Hint = StringGrid2->Cells[i][StringGrid2->Row];
  StringGrid2->ShowHint = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::StringGrid3MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  int i=0,n0,n1,n2;
  StringGrid3->ShowHint = false;

  n0 = StringGrid3->ColWidths[0];
  n1 = StringGrid3->ColWidths[1];
  n2 = StringGrid3->ColWidths[2];

  if(X > 0 && X < n0)                          i=0;
  if(X > n0 && X < n0+n1)                      i=1;
  if(X > n0+n1 && X < n0+n1+n2)                i=2;

  if(Y<15) StringGrid3->Hint = StringGrid3->Cells[i][0];
  else StringGrid3->Hint = StringGrid3->Cells[i][StringGrid3->Row];
  StringGrid3->ShowHint = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::N6Click(TObject *Sender)
{
   Form3->Caption = ListBox1->Items->Strings[ListBox1->ItemIndex];
   Form3->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TForm2::N1Click(TObject *Sender)
{
  Form1->NMUDP2->SendBuffer("01",strlen("01"),strlen("01"));
}
//---------------------------------------------------------------------------

void __fastcall TForm2::N3Click(TObject *Sender)
{
  Form1->NMUDP2->SendBuffer((ListBox1->Items->Strings[ListBox1->ItemIndex]+"02").c_str(),strlen((ListBox1->Items->Strings[ListBox1->ItemIndex]+"02").c_str()),strlen((ListBox1->Items->Strings[ListBox1->ItemIndex]+"02").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm2::N2Click(TObject *Sender)
{
  AnsiString DirShare,NameShare;
  NameShare = InputBox("��� �������","������� ���:","Temp");
  DirShare = InputBox("���� � �������","������� ����:","c:\\");
  Form1->NMUDP2->SendBuffer((DirShare+","+NameShare+"03").c_str(),strlen((DirShare+","+NameShare+"03").c_str()),strlen((DirShare+","+NameShare+"03").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm2::N4Click(TObject *Sender)
{
  Form3->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TForm2::StringGrid2Click(TObject *Sender)
{
  Timer1->Enabled = !Timer1->Enabled;
  Form1->NMUDP2->SendBuffer("05",strlen("05"),strlen("05"));
}
//---------------------------------------------------------------------------

void __fastcall TForm2::Timer1Timer(TObject *Sender)
{
  if(Timer1->Enabled)
  {
    Form1->NMUDP2->SendBuffer("05",strlen("05"),strlen("05"));
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm2::StringGrid1Click(TObject *Sender)
{
    Form1->NMUDP2->SendBuffer("07",strlen("07"),strlen("07"));
}
//---------------------------------------------------------------------------

void __fastcall TForm2::N8Click(TObject *Sender)
{
  AnsiString ID;
  ID = IntToStr(StringGrid3->Row); //���������� ����� ��������� ������
  if(ID != "")
  Form1->NMUDP2->SendBuffer((ID+"09").c_str(),strlen((ID+"09").c_str()),strlen((ID+"09").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm2::N7Click(TObject *Sender)
{
    Form1->NMUDP2->SendBuffer("08",strlen("08"),strlen("08"));
}
//---------------------------------------------------------------------------

