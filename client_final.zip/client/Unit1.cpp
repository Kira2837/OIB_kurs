//---------------------------------------------------------------------------
#include <vcl.h>
#include <time.h>
#include <winsock.h>
#include <IniFiles.hpp>
#include <systdate.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

    hostent *P;
    in_addr in;
    TIniFile *Ini,*Mag;
    bool ScanStart = false;
    int Ad,Ad1,Ad2,Ad3,Ad4,Progres;
    AnsiString HostName,HostAdres;
    AnsiString CurrentDir;
    int scans=0,maxscan=1;
    clock_t tstart,tfinish;
    UINT_PTR Tim;


//---------------------------------------------------------------------------

TStringList *ipAll()
{
 TStringList *iplst = new TStringList();
 int cnt = Form1->StringGrid1->RowCount;
 for(int i=1;i<cnt;i++)
  iplst->Add(Form1->StringGrid1->Cells[2][i]);
 return iplst;
 delete iplst;
}

bool ifSendOk()
{
 int userResponse;
  userResponse=MessageDlg("���������?",mtConfirmation, TMsgDlgButtons() << mbNo <<mbYes,0);
  if(userResponse==mrYes) return true;
  else return false;
}

// ������� ������ ����� ������

void sendAll(AnsiString cmdNumber)
{
   int cnt_s = ipAll()->Count;
   for(int i=0;i<cnt_s;i++)
   {
    Form1->NMStrm1->Host = ipAll()->Strings[i];
    Form1->NMStrmServ1->Host = ipAll()->Strings[i];
    Form1->NMStrmServ2->Host = ipAll()->Strings[i];
    Form1->NMUDP2->RemoteHost = ipAll()->Strings[i];
    Form1->NMUDP2->SendBuffer(cmdNumber.c_str(),strlen(cmdNumber.c_str()),strlen(cmdNumber.c_str()));
   }
}



void __fastcall TForm1::FormCreate(TObject *Sender)
{
    ScD = false;
    CurrentDir = GetCurrentDir();
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    Ini = new TIniFile((CurrentDir + "\\Config.ini").c_str());

    Mag = new TIniFile((CurrentDir + "\\Events.mag").c_str());
    if(!Mag) ShowMessage("�� ���� ������� ������ �������!");
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    char s[128];
    char *P2;
    gethostname(s, 128);
    P = gethostbyname(s);
    HostName = P->h_name;
    in.S_un.S_un_b.s_b1 = P->h_addr_list[0][0];
    in.S_un.S_un_b.s_b2 = P->h_addr_list[0][1];
    in.S_un.S_un_b.s_b3 = P->h_addr_list[0][2];
    in.S_un.S_un_b.s_b4 = P->h_addr_list[0][3];
    P2 = inet_ntoa(in);
    HostAdres = P2;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    Edit2->Text = in.S_un.S_un_b.s_b1;
    Edit3->Text = in.S_un.S_un_b.s_b2;
    Edit4->Text = in.S_un.S_un_b.s_b3;
    Edit5->Text = "0";
    Edit6->Text = Edit2->Text;
    Edit7->Text = Edit3->Text;
    Edit8->Text = Edit4->Text;
    Edit9->Text = "255";
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    Memo1->Lines->Add("��� ����������:   "+HostName);
    Memo1->Lines->Add("����� ����������: "+HostAdres);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    StringGrid1->Cells[0][0] = "�";
    StringGrid1->Cells[1][0] = "�����:";
    StringGrid1->Cells[2][0] = "��� ����������:";
    StringGrid1->Cells[0][1] = "1";

    NMUDP1->LocalPort = Ini->ReadInteger("net","LocalPort",0);
    NMUDP1->RemotePort = Ini->ReadInteger("net","RemotePort",0);
    NMStrmServ1->Port = Ini->ReadInteger("net","PortSer",0);
    NMStrm1->Port = Ini->ReadInteger("net","PortCl",0);
    int user = Ini->ReadInteger("user","count",0);
    maxscan = user;
    maxscan++;
    StringGrid1->RowCount = user+1;
    StringGrid2->RowCount = user+1;
    for(int i=1;i<user+1;i++)
    {
      StringGrid1->Cells[0][i] = IntToStr(i);
      StringGrid1->Cells[1][i] = Ini->ReadString("Name",IntToStr(i),"Error");
      StringGrid1->Cells[2][i] = Ini->ReadString("Addres",IntToStr(i),"Error");

      StringGrid2->Cells[0][i] = IntToStr(i);
      StringGrid2->Cells[1][i] = Ini->ReadString("Name",IntToStr(i),"Error");
      StringGrid2->Cells[2][i] = Ini->ReadString("Addres",IntToStr(i),"Error");
      StringGrid2->Cells[3][i] = Ini->ReadString("Resurs",IntToStr(i),"Error");
      StringGrid2->Cells[4][i] = Ini->ReadString("Podkluchenie",IntToStr(i),"Error");
      StringGrid2->Cells[5][i] = Ini->ReadString("Dopusk",IntToStr(i),"Error");
      StringGrid2->Cells[6][i] = Ini->ReadString("Sostoyanie",IntToStr(i),"Error");
    }
//==========================================
    StringGrid2->Cells[0][0] = "�";
    StringGrid2->Cells[1][0] = "��� ����������";
    StringGrid2->Cells[2][0] = "�����";
    StringGrid2->Cells[3][0] = "�������";
    StringGrid2->Cells[4][0] = "�����������";
    StringGrid2->Cells[5][0] = "����� �������";
    StringGrid2->Cells[6][0] = "���������";
    StringGrid2->Cells[0][1] = "1";
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
}
//---------------------------------------------------------------------------

void __fastcall TForm1::StringGrid2DblClick(TObject *Sender)
{
  Form2->Caption = StringGrid2->Cells[1][StringGrid2->Row] + " : " + StringGrid2->Cells[2][StringGrid2->Row];
  Form2->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton2Click(TObject *Sender)
{
  Edit1->Enabled = true;Edit2->Enabled = true;Edit3->Enabled = true;
  Edit4->Enabled = true;Edit5->Enabled = true;Edit6->Enabled = true;
  Edit7->Enabled = true;Edit8->Enabled = true;Edit9->Enabled = true;
  CheckBox1->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton1Click(TObject *Sender)
{
  Edit1->Enabled = false;Edit2->Enabled = false;Edit3->Enabled = false;
  Edit4->Enabled = false;Edit5->Enabled = false;Edit6->Enabled = false;
  Edit7->Enabled = false;Edit8->Enabled = false;Edit9->Enabled = false;
  CheckBox1->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
  ScanStart = !ScanStart;
  if(ScanStart && RadioButton1->Checked)
   {
     ScanStart = !ScanStart;
     NMUDP1->RemoteHost = (AnsiString)in.S_un.S_un_b.s_b1 + "." + (AnsiString)in.S_un.S_un_b.s_b2 + "." + (AnsiString)in.S_un.S_un_b.s_b3 + ".255";
     tstart = 0;
     tfinish = 0;
     tstart = clock();
     NMUDP1->SendBuffer("hallo",strlen("hallo"),strlen("hallo"));
   }
  if(ScanStart && RadioButton2->Checked)
   {
     Timer2->Enabled = ScanStart;
     BitBtn1->Caption = "����������";
     Ad1 = StrToInt(Edit2->Text);
     Ad2 = StrToInt(Edit3->Text);
     Ad3 = StrToInt(Edit4->Text);
     Ad4 = StrToInt(Edit5->Text);

     Progres = 0;
     CGauge1->MinValue = 0;
     CGauge1->MaxValue = ((StrToInt(Edit8->Text) - StrToInt(Edit4->Text))+1)*254;
   }
  else          BitBtn1->Caption = "������";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
  if(CheckBox1->Checked) BitBtn1Click(Form1);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Edit1Change(TObject *Sender)
{
  try
  {
    Timer1->Interval = StrToFloat(Edit1->Text)*1000;
  }
  catch(...)
  {
    Edit1->Text = "0.5";
    Timer1->Interval = 500;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer2Timer(TObject *Sender)
{
  if(ScanStart)
  {
    if(Edit5->Text != Edit9->Text)
     {
       Ad4++;
       Edit5->Text = IntToStr(Ad4);
       Progres++;
     }
    else
    if(Edit4->Text != Edit8->Text)
     {
       Ad3++;
       Edit4->Text = IntToStr(Ad3);
       Edit5->Text = "0";
       Ad4 = 0;
       Edit9->Text = "254";
     }
    else
    if(Edit3->Text != Edit7->Text)
     {
       Ad2++;
       Edit3->Text = IntToStr(Ad2);
       Edit5->Text = "0";
       Ad4 = 0;
       Edit4->Text = "0";
       Ad3 = 0;
       Edit9->Text = "254";
       Edit8->Text = "254";
     }
    else
    if(Edit2->Text != Edit6->Text)
     {
       Ad1++;
       Edit2->Text = IntToStr(Ad1);
       Edit5->Text = "0";
       Ad4 = 0;
       Edit4->Text = "0";
       Ad3 = 0;
       Edit3->Text = "0";
       Ad2 = 0;
       Edit9->Text = "254";
       Edit8->Text = "254";
       Edit7->Text = "254";
     }
    else BitBtn1Click(Form1);
    NMUDP1->RemoteHost = Edit2->Text + "." + Edit3->Text + "." + Edit4->Text + "." + Edit5->Text;
    NMUDP1->SendBuffer("hallo",strlen("hallo"),strlen("hallo"));
    CGauge1->Progress = Progres;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Hello(char* Buff)
{

  KillTimer(NULL,Tim);
  int n,j,i;
  AnsiString Name,Addres,Resurs,Podkluchenie,Dopusk,Sostoyanie;

  for(i=0;i<strlen(Buff);i++)  {j = i;if(Buff[i] == ':') break;
                                        Name = Name + Buff[i];}
  for(i=j+1;i<strlen(Buff);i++){j = i;if(Buff[i] == ':') break;
                                        Addres = Addres + Buff[i];}
  for(i=j+1;i<strlen(Buff);i++){j = i;if(Buff[i] == ':') break;
                                        Resurs = Resurs + Buff[i];}
  for(i=j+1;i<strlen(Buff);i++){j = i;if(Buff[i] == ':') break;
                                        Podkluchenie = Podkluchenie + Buff[i];}
  for(i=j+1;i<strlen(Buff);i++){j = i;if(Buff[i] == ':') break;
                                        Dopusk = Dopusk + Buff[i];}
  for(i=j+1;i<strlen(Buff);i++){j = i;if(Buff[i] == ':') break;
                                        Sostoyanie = Sostoyanie + Buff[i];}

  int user = Ini->ReadInteger("user","count",0);
  maxscan = user + 1;
  n = StringGrid1->RowCount;
  for(i=1;i<n;i++)
   if(Name == StringGrid1->Cells[1][i])
     if(Addres == StringGrid1->Cells[2][i])
      {
        StringGrid2->Cells[1][i] = Name;
        StringGrid2->Cells[2][i] = Addres;
        StringGrid2->Cells[3][i] = Resurs;
        StringGrid2->Cells[4][i] = Podkluchenie;
        StringGrid2->Cells[5][i] = (tfinish - tstart);
        StringGrid2->Cells[6][i] = "�������";
        //Ini->WriteString("Name",IntToStr(i),Name);
        //Ini->WriteString("Addres",IntToStr(i),Addres);
        //Ini->WriteString("Resurs",IntToStr(i),Resurs);
        //Ini->WriteString("Podkluchenie",IntToStr(i),Podkluchenie);
        //Ini->WriteString("Dopusk",IntToStr(i),(tfinish - tstart));
        //Ini->WriteString("Sostoyanie",IntToStr(i),"�������");
        break;
      }
  if(StringGrid1->RowCount == i)
  {
    StringGrid1->RowCount++;
    StringGrid2->RowCount++;
    StringGrid1->Cells[0][StringGrid1->RowCount-1] = StringGrid1->RowCount-1;
    StringGrid1->Cells[1][StringGrid1->RowCount-1] = Name;
    StringGrid1->Cells[2][StringGrid1->RowCount-1] = Addres;

    StringGrid2->Cells[0][StringGrid1->RowCount-1] = StringGrid1->RowCount-1;
    StringGrid2->Cells[1][StringGrid1->RowCount-1] = Name;
    StringGrid2->Cells[2][StringGrid1->RowCount-1] = Addres;
    StringGrid2->Cells[3][StringGrid1->RowCount-1] = Resurs;
    StringGrid2->Cells[4][StringGrid1->RowCount-1] = Podkluchenie;
    StringGrid2->Cells[5][StringGrid1->RowCount-1] = (tfinish - tstart);
    StringGrid2->Cells[6][StringGrid1->RowCount-1] = "�������";
    //Ini->WriteInteger("user","count",user+1);
    //Ini->WriteString("Name",IntToStr(user+1),Name);
    //Ini->WriteString("Addres",IntToStr(user+1),Addres);
    //Ini->WriteString("Resurs",IntToStr(user+1),Resurs);
    //Ini->WriteString("Podkluchenie",IntToStr(user+1),Podkluchenie);
    //Ini->WriteString("Dopusk",IntToStr(user+1),(tfinish - tstart));
    //Ini->WriteString("Sostoyanie",IntToStr(user+1),"�������");
    Mag->WriteString(DateToStr(Date()),TimeToStr(Time()),"����� ���������: " + Name + " : " + Addres);
    ShowMessage("����� ���������: " + Name + " : " + Addres);
  }
  return;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Shares(char *Buf)
{
  char t;
  AnsiString temp;
  int n=0,i;
  n = strlen(Buf);
  Form2->ListBox1->Clear();
  for(i=0;i<n;i++)
  {
    t = Buf[i];
    if(t == ',') {Form2->ListBox1->Items->Add(temp);temp="";}
    else         temp += Buf[i];
  }
  return;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Traff(char *Buf)
{
  char t;
  AnsiString temp;
  int n=0,i,j1=0,j2=1;
  n = strlen(Buf);
  Form2->StringGrid2->RowCount =2;
  for(i=0;i<n;i++)
  {
    t = Buf[i];
    if(t == '~' || t == '@')
     {
       Form2->StringGrid2->Cells[j1][j2] = temp;
       temp="";
       j1++;
     }
    else temp += Buf[i];
    if(t == '@')
     {
       j1=0;j2++;
       Form2->StringGrid2->RowCount ++;
     }
  }
  return;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Sesion(char *Buf)
{
  char t;
  AnsiString temp;
  int n=0,i,j1=0,j2=1;
  n = strlen(Buf);
  Form2->StringGrid2->RowCount =2;
  for(i=0;i<n;i++)
  {
    t = Buf[i];
    if(t == '~' || t == '@')
     {
       Form2->StringGrid1->Cells[j1][j2] = temp;
       temp="";
       j1++;
     }
    else temp += Buf[i];
    if(t == '@')
     {
       j1=0;j2++;
       Form2->StringGrid1->RowCount ++;
     }
  }
  return;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SesionFiles(char *Buf)
{
  char t;
  AnsiString temp;
  int n=0,i,j1=0,j2=1;
  n = strlen(Buf);
  Form2->StringGrid3->RowCount =2;
  for(i=0;i<n;i++)
  {
    t = Buf[i];
    if(t == '~' || t == '@')
     {
       Form2->StringGrid3->Cells[j1][j2] = temp;
       temp="";
       j1++;
     }
    else temp += Buf[i];
    if(t == '@')
     {
       j1=0;j2++;
       Form2->StringGrid3->RowCount ++;
     }
  }
  return;
}

//---------------------------------------------------------------------------

void __fastcall TForm1::NMUDP1DataReceived(TComponent *Sender,
      int NumberBytes, AnsiString FromIP, int Port)
{
  char command[3];
  if (NumberBytes<512)
   {
     char Buff[512];
     int j;
     NMUDP1->ReadBuffer(Buff, 512, j);
     Buff[j]=0;
     command[0] = Buff[j-2];
     command[1] = Buff[j-1];
     command[2] = 0;
     Buff[j-2] = 0;
     Buff[j-1] = 0;
     if(strcmp(command,"00") == 0) {tfinish = clock();Hello(Buff);}
   }
  else
     Memo1->Lines->Add("Buffer too small for data");
}
//---------------------------------------------------------------------------
void TimFun(HWND hwnd, UINT msg, UINT_PTR Tim, DWORD dwtime)
{
  KillTimer(NULL,Tim);
  if (Form1->StringGrid2->Cells[6][scans] != "�� �������" && scans != 0)
  {
    Form1->StringGrid2->Cells[6][scans] = "�� �������";
    Beep();
    Mag->WriteString(DateToStr(Date()),TimeToStr(Time()),"���������: "+Form1->StringGrid2->Cells[1][scans]+" : "+Form1->StringGrid2->Cells[2][scans]+" �������!");
    ShowMessage("���������: "+Form1->StringGrid2->Cells[1][scans]+" : "+Form1->StringGrid2->Cells[2][scans]+" �������!");
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer3Timer(TObject *Sender)
{
    scans++;
    if(scans == maxscan)
    {
       scans=0;
       NMUDP1->RemoteHost = (AnsiString)in.S_un.S_un_b.s_b1 + "." + (AnsiString)in.S_un.S_un_b.s_b2 + "." + (AnsiString)in.S_un.S_un_b.s_b3 + ".255";
       tstart = 0;
       tfinish = 0;
       tstart = clock();
       NMUDP1->SendBuffer("hallo",strlen("hallo"),strlen("hallo"));
    }
    else
    {
      Tim = SetTimer(NULL,NULL,500,(TIMERPROC)TimFun);
      NMUDP1->RemoteHost = StringGrid2->Cells[2][scans];
      tstart = 0;
      tfinish = 0;
      tstart = clock();
      NMUDP1->SendBuffer("hallo",strlen("hallo"),strlen("hallo"));
    }
}
//---------------------------------------------------------------------------

#include <jpeg.hpp>
void __fastcall TForm1::NMStrmServ1MSG(TComponent *Sender,
      const AnsiString sFrom, TStream *strm)
{
  TJPEGImage *a;
  a = new TJPEGImage();
  if (FileExists("c:\\SD.jpg"))
    DeleteFile("c:\\SD.jpg");

  TFileStream *MyFStream;
  MyFStream = new TFileStream("c:\\SD.jpg", fmCreate);
  try
  {
    MyFStream->CopyFrom(strm, strm->Size);
  }
  catch(...)
  {
  }
  MyFStream->Free();
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  a->LoadFromFile("c:\\SD.jpg");
  Form3->Image1->Picture->Graphic = a;
  DeleteFile("c:\\SD.jpg");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::NMUDP2DataReceived(TComponent *Sender,
      int NumberBytes, AnsiString FromIP, int Port)
{
  char command[3];
  if (NumberBytes<512)
   {
     char Buff[512];
     int j;
     NMUDP2->ReadBuffer(Buff, 512, j);
     Buff[j]=0;
     command[0] = Buff[j-2];
     command[1] = Buff[j-1];
     command[2] = 0;
     Buff[j-2] = 0;
     Buff[j-1] = 0;
     if(strcmp(command,"01") == 0) {Shares(Buff);}
     if(strcmp(command,"05") == 0) {Traff(Buff);}
     if(strcmp(command,"07") == 0) {Sesion(Buff);}
     if(strcmp(command,"08") == 0) {SesionFiles(Buff);}
     if(strcmp(command,"09") == 0) {Edit11->Text = Buff;}
   }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn2Click(TObject *Sender)
{
    if(N4->Checked && ifSendOk()) sendAll("10");
     else
    NMUDP2->SendBuffer("10",strlen("10"),strlen("10"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn3Click(TObject *Sender)
{
    if(N4->Checked) sendAll("11");
     else
    NMUDP2->SendBuffer("11",strlen("11"),strlen("11"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn4Click(TObject *Sender)
{
    if(N4->Checked) sendAll("12");
     else
    NMUDP2->SendBuffer("12",strlen("12"),strlen("12"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn5Click(TObject *Sender)
{
    if(N4->Checked) sendAll("13");
     else
    NMUDP2->SendBuffer("13",strlen("13"),strlen("13"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn6Click(TObject *Sender)
{
    if(N4->Checked) sendAll("14");
     else
    NMUDP2->SendBuffer("14",strlen("14"),strlen("14"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn7Click(TObject *Sender)
{
    if(N4->Checked) sendAll((Edit10->Text+"15").c_str());
     else
    NMUDP2->SendBuffer((Edit10->Text+"15").c_str(),strlen((Edit10->Text+"15").c_str()),strlen((Edit10->Text+"15").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn8Click(TObject *Sender)
{
   if(N4->Checked) sendAll("16");
    else
   NMUDP2->SendBuffer("16",strlen("16"),strlen("16"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn9Click(TObject *Sender)
{
  if(ListBox1->ItemIndex>=0)
     if(N4->Checked) sendAll((ListBox1->Items->Strings[ListBox1->ItemIndex]+"17").c_str());
      else
     NMUDP2->SendBuffer((ListBox1->Items->Strings[ListBox1->ItemIndex]+"17").c_str(),strlen((ListBox1->Items->Strings[ListBox1->ItemIndex]+"17").c_str()),strlen((ListBox1->Items->Strings[ListBox1->ItemIndex]+"17").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn10Click(TObject *Sender)
{
    AnsiString Name;
    Name = InputBox("����������� ����","������� ���� � ��� �����:","c:\\");
    NMUDP2->SendBuffer((Name+"18").c_str(),strlen((Name+"18").c_str()),strlen((Name+"18").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn11Click(TObject *Sender)
{
    NMUDP2->SendBuffer("19",strlen("19"),strlen("19"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn12Click(TObject *Sender)
{
    AnsiString From,To;
    From = InputBox("������ ����������","������� ���� � ��� �����:","c:\\");
    To = InputBox("���� ����������","������� ���� � ��� �����:","c:\\");
    if(From != "" && To != "")
    {
    TFileStream *MyFStream;
    MyFStream = new TFileStream(From, fmOpenRead);
    try
    {
      NMStrm1->FromName = To;
      NMStrm1->PostIt(MyFStream);
    }
    catch(...)
    {
    }
    MyFStream->Free();
    }
    else ShowMessage("Error");
}
//---------------------------------------------------------------------------
AnsiString FromF,ToF;

void __fastcall TForm1::BitBtn13Click(TObject *Sender)
{
    FromF = InputBox("������ ����������","������� ���� � ��� �����:","c:\\");
    ToF = InputBox("���� ����������","������� ���� � ��� �����:","c:\\");
    NMUDP2->SendBuffer((FromF+"20").c_str(),strlen((FromF+"20").c_str()),strlen((FromF+"20").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn14Click(TObject *Sender)
{
   AnsiString Name;
   Name = InputBox("����������","������� ��� ����������:","c:");
   NMUDP2->SendBuffer((Name+"21").c_str(),strlen((Name+"21").c_str()),strlen((Name+"21").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn15Click(TObject *Sender)
{
   AnsiString From,To;
   From = InputBox("���� � �����","������� ���� � ��� �����:","c:\\belkin.exe");
   To = InputBox("����� ��� �����","������� ���� � ����� ��� �����:","c:\\Temp.exe");
   NMUDP2->SendBuffer((From+","+To+"22").c_str(),strlen((From+","+To+"22").c_str()),strlen((From+","+To+"22").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn16Click(TObject *Sender)
{
    AnsiString Name;
    Name = InputBox("������� ����","������� ���� � ��� �����:","c:\\");
    NMUDP2->SendBuffer((Name+"23").c_str(),strlen((Name+"23").c_str()),strlen((Name+"23").c_str()));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::NMStrmServ2MSG(TComponent *Sender,
      const AnsiString sFrom, TStream *strm)
{
  if (FileExists("c:\\tmp.txt"))
    DeleteFile("c:\\tmp.txt");
  TFileStream *MyFStream;
  MyFStream = new TFileStream("c:\\tmp.txt", fmCreate);
  try
  {
    MyFStream->CopyFrom(strm, strm->Size);
  }
  catch(...)
  {
  }
  MyFStream->Free();
  if(sFrom == "process" || sFrom == "filesdir")
  {
    ListBox1->Clear();
    ListBox1->Items->LoadFromFile("c:\\tmp.txt");
    ListBox1->Repaint();
  }
  else
  if(sFrom == "dir")
  {
    TreeView1->LoadFromFile("c:\\tmp.txt");
  }
  else
  if(sFrom == "filefrom")
  {
    CopyFile("c:\\tmp.txt",ToF.c_str(),true);
  }
  DeleteFile("c:\\tmp.txt");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::StringGrid1Click(TObject *Sender)
{
   StatusBar1->Panels->Items[1]->Text = "���: " + StringGrid1->Cells[1][StringGrid1->Row];
   StatusBar1->Panels->Items[2]->Text = "�����: " + StringGrid1->Cells[2][StringGrid1->Row];
   NMStrm1->Host = StringGrid1->Cells[2][StringGrid1->Row];
   NMStrmServ1->Host = StringGrid1->Cells[2][StringGrid1->Row];
   NMStrmServ2->Host = StringGrid1->Cells[2][StringGrid1->Row];
   NMUDP2->RemoteHost = StringGrid1->Cells[2][StringGrid1->Row];
}
//---------------------------------------------------------------------------


void __fastcall TForm1::BitBtn17Click(TObject *Sender)
{
if(N4->Checked) sendAll("30");
 else
NMUDP2->SendBuffer("30",strlen("30"),strlen("30"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn18Click(TObject *Sender)
{
if(N4->Checked) sendAll("31");
 else
NMUDP2->SendBuffer("31",strlen("31"),strlen("31"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn19Click(TObject *Sender)
{
if(N4->Checked) sendAll("32");
 else
NMUDP2->SendBuffer("32",strlen("32"),strlen("32"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn20Click(TObject *Sender)
{
if(N4->Checked)
 {
  if(RadioButton3->Checked==true) sendAll("33");
  if(RadioButton4->Checked==true) sendAll("34");
  if(RadioButton5->Checked==true) sendAll("34");
  if(RadioButton6->Checked==true) sendAll("35");
 }
 else
 {
if(RadioButton3->Checked==true) NMUDP2->SendBuffer("33",strlen("33"),strlen("33"));
if(RadioButton4->Checked==true) NMUDP2->SendBuffer("34",strlen("34"),strlen("34"));
if(RadioButton5->Checked==true) NMUDP2->SendBuffer("35",strlen("35"),strlen("35"));
if(RadioButton6->Checked==true) NMUDP2->SendBuffer("36",strlen("36"),strlen("36"));
 }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn21Click(TObject *Sender)
{
if(N4->Checked) sendAll("37");
 else
NMUDP2->SendBuffer("37",strlen("37"),strlen("37"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn22Click(TObject *Sender)
{
if(N4->Checked) sendAll("38");
 else
NMUDP2->SendBuffer("38",strlen("38"),strlen("38"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn23Click(TObject *Sender)
{
if(N4->Checked) sendAll("39");
 else
NMUDP2->SendBuffer("39",strlen("39"),strlen("39"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn24Click(TObject *Sender)
{
if(N4->Checked) sendAll("40");
 else
NMUDP2->SendBuffer("40",strlen("40"),strlen("40"));
}
//---------------------------------------------------------------------------




void __fastcall TForm1::BitBtn28Click(TObject *Sender)
{
if(N4->Checked) sendAll("43");
 else
NMUDP2->SendBuffer("43",strlen("43"),strlen("43"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn25Click(TObject *Sender)
{
if(N4->Checked) sendAll("42");
 else
NMUDP2->SendBuffer("42",strlen("42"),strlen("42"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn26Click(TObject *Sender)
{
if(N4->Checked) sendAll("44");
 else
NMUDP2->SendBuffer("44",strlen("44"),strlen("44"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn27Click(TObject *Sender)
{
if(N4->Checked) sendAll("45");
 else
NMUDP2->SendBuffer("45",strlen("45"),strlen("45"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn29Click(TObject *Sender)
{
if(N4->Checked) sendAll("47");
 else
NMUDP2->SendBuffer("47",strlen("47"),strlen("47"));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn30Click(TObject *Sender)
{
if(N4->Checked) sendAll("46");
 else
NMUDP2->SendBuffer("46",strlen("46"),strlen("46"));
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
void __fastcall TForm1::N4Click(TObject *Sender)
{
if(N3->Checked)
 {
  N3->Checked = false;
  N4->Checked = true;
 }
else N4->Checked = true;

// ���������� ������, ���������� ��� �������������� ������

BitBtn8->Enabled = false;         // ���������� ��������
BitBtn9->Enabled = false;         // �������� �������
BitBtn10->Enabled = false;        // ��������� �������
BitBtn11->Enabled = false;        // ��� ����������
BitBtn12->Enabled = false;        // ���������� ��
BitBtn13->Enabled = false;        // ���������� �
BitBtn14->Enabled = false;        // ����� � ����������
BitBtn15->Enabled = false;        // ������������� ����
BitBtn16->Enabled = false;        // ������� ����

}
//---------------------------------------------------------------------------

void __fastcall TForm1::N3Click(TObject *Sender)
{
if(N4->Checked)
 {
  N4->Checked = false;
  N3->Checked = true;
 }
else N3->Checked = true;

BitBtn8->Enabled = true;         // ���������� ��������
BitBtn9->Enabled = true;         // �������� �������
BitBtn10->Enabled = true;        // ��������� �������
BitBtn11->Enabled = true;        // ��� ����������
BitBtn12->Enabled = true;        // ���������� ��
BitBtn13->Enabled = true;        // ���������� �
BitBtn14->Enabled = true;        // ����� � ����������
BitBtn15->Enabled = true;        // ������������� ����
BitBtn16->Enabled = true;        // ������� ����

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
     if(N4->Checked) sendAll("48");
        else
        NMUDP2->SendBuffer("48",strlen("48"),strlen("48"));
}
//---------------------------------------------------------------------------





